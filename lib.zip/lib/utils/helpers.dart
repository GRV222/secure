import 'package:flutter/material.dart';

/// Shows a snackbar at bottom
void showSnackBar(BuildContext context, String message, {bool error = false}) {
  final snackBar = SnackBar(
    content: Text(message),
    backgroundColor: error ? Colors.red : Colors.green,
  );
  ScaffoldMessenger.of(context).showSnackBar(snackBar);
}

/// Formats a DateTime nicely
String formatDate(DateTime dt) {
  return '${dt.year.toString().padLeft(4, '0')}-'
      '${dt.month.toString().padLeft(2, '0')}-'
      '${dt.day.toString().padLeft(2, '0')}';
}
