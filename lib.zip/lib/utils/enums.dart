/// Post types across the app
enum PostType { competition, dare, task, idea, poll }

/// Dare/task separation
enum DareTaskType { dare, task }

/// Media types
enum MediaType { image, video, audio, document }
