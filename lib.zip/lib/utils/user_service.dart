// lib/services/user_service.dart
import 'package:cloud_firestore/cloud_firestore.dart';

class UserService {
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  Future<void> saveUserProfile({
    required String uid,
    required String name,
    required String phone,
    required int age,
    required String profession,
    String? gender,
    String? imageUrl,
    bool isAdmin = false,
  }) async {
    await _firestore.collection('users').doc(uid).set({
      'name': name,
      'phone': phone,
      'age': age,
      'profession': profession,
      'gender': gender,
      'imageUrl': imageUrl,
      'isAdmin': isAdmin,
      'createdAt': Timestamp.now(),
    });
  }
}
