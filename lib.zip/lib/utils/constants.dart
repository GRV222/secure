import 'package:flutter/material.dart';

class AppConstants {
  // Firebase collections
  static const String usersCollection = 'users';
  static const String postsCollection = 'posts';
  static const String pollsCollection = 'polls';
  static const String ratingsCollection = 'ratings';
  static const String commentsCollection = 'comments';
  static const String dareTasksCollection = 'dare_tasks';
  static const String competitionsCollection = 'competitions';

  // App theming
  static const Color primaryColor = Colors.blue;
  static const Color accentColor = Colors.blueAccent;
  static const double padding = 16.0;
}
