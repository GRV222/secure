// lib/screens/auth/user_info_screen.dart
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import '../../services/user_service.dart';

class UserInfoScreen extends StatefulWidget {
  final String uid;
  final String phone;
  const UserInfoScreen({super.key, required this.uid, required this.phone});

  @override
  State<UserInfoScreen> createState() => _UserInfoScreenState();
}

class _UserInfoScreenState extends State<UserInfoScreen> {
  final _formKey = GlobalKey<FormState>();
  final _userService = UserService();
  final ImagePicker _picker = ImagePicker();

  File? _image;
  String name = '';
  String profession = '';
  int age = 18;
  String? gender;

  Future<void> _pickImage() async {
    final picked = await _picker.pickImage(source: ImageSource.gallery);
    if (picked != null) {
      setState(() => _image = File(picked.path));
    }
  }

  void _submitProfile() async {
    if (_formKey.currentState!.validate()) {
      // Save to Firebase
      await _userService.saveUserProfile(
        uid: widget.uid,
        name: name,
        phone: widget.phone,
        age: age,
        profession: profession,
        gender: gender,
        imageUrl: null, // image upload optional for now
      );
      Navigator.pushReplacementNamed(context, '/home'); // or admin panel
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Complete Your Profile")),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Form(
          key: _formKey,
          child: ListView(
            children: [
              GestureDetector(
                onTap: _pickImage,
                child: CircleAvatar(
                  radius: 40,
                  backgroundImage: _image != null ? FileImage(_image!) : null,
                  child: _image == null ? const Icon(Icons.camera_alt) : null,
                ),
              ),
              const SizedBox(height: 16),
              TextFormField(
                decoration: const InputDecoration(labelText: "Name"),
                validator: (val) =>
                    val == null || val.isEmpty ? "Enter name" : null,
                onChanged: (val) => name = val,
              ),
              TextFormField(
                decoration: const InputDecoration(labelText: "Age"),
                keyboardType: TextInputType.number,
                onChanged: (val) => age = int.tryParse(val) ?? 18,
              ),
              TextFormField(
                decoration: const InputDecoration(labelText: "Profession"),
                onChanged: (val) => profession = val,
              ),
              DropdownButtonFormField(
                decoration: const InputDecoration(labelText: "Gender"),
                items: const [
                  DropdownMenuItem(value: "Male", child: Text("Male")),
                  DropdownMenuItem(value: "Female", child: Text("Female")),
                  DropdownMenuItem(value: "Other", child: Text("Other")),
                ],
                onChanged: (val) => gender = val,
              ),
              const SizedBox(height: 20),
              ElevatedButton(
                onPressed: _submitProfile,
                child: const Text("Submit"),
              )
            ],
          ),
        ),
      ),
    );
  }
}
