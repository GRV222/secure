import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import '../../routes.dart';
import '../../utils/constants.dart';

class SignupScreen extends StatefulWidget {
  const SignupScreen({super.key});

  @override
  State<SignupScreen> createState() => _SignupScreenState();
}

class _SignupScreenState extends State<SignupScreen> {
  final _formKey = GlobalKey<FormState>();
  final FirebaseAuth _auth = FirebaseAuth.instance;

  String name = '';
  String email = '';
  String password = '';
  bool isAdmin = false;
  bool loading = false;

  void signup() async {
    if (!_formKey.currentState!.validate()) return;

    setState(() => loading = true);

    try {
      UserCredential result = await _auth.createUserWithEmailAndPassword(
        email: email,
        password: password,
      );

      await FirebaseFirestore.instance
          .collection('users')
          .doc(result.user!.uid)
          .set({
        'name': name,
        'email': email,
        'isAdmin': isAdmin,
        'uid': result.user!.uid,
        'createdAt': Timestamp.now(),
      });

      if (isAdmin) {
        Navigator.pushReplacementNamed(context, AppRoutes.adminDashboard);
      } else {
        Navigator.pushReplacementNamed(context, AppRoutes.home);
      }
    } catch (e) {
      ScaffoldMessenger.of(context)
          .showSnackBar(SnackBar(content: Text(e.toString())));
    } finally {
      setState(() => loading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.bgColor,
      appBar: AppBar(title: const Text("Signup")),
      body: loading
          ? const Center(child: CircularProgressIndicator())
          : Padding(
              padding: const EdgeInsets.all(24.0),
              child: Form(
                key: _formKey,
                child: ListView(
                  children: [
                    TextFormField(
                      decoration: const InputDecoration(labelText: 'Name'),
                      onChanged: (val) => name = val,
                      validator: (val) =>
                          val!.isEmpty ? 'Enter your name' : null,
                    ),
                    const SizedBox(height: 12),
                    TextFormField(
                      decoration: const InputDecoration(labelText: 'Email'),
                      onChanged: (val) => email = val,
                      validator: (val) =>
                          val!.contains('@') ? null : 'Enter valid email',
                    ),
                    const SizedBox(height: 12),
                    TextFormField(
                      obscureText: true,
                      decoration: const InputDecoration(labelText: 'Password'),
                      onChanged: (val) => password = val,
                      validator: (val) =>
                          val!.length < 6 ? 'Min 6 characters' : null,
                    ),
                    const SizedBox(height: 12),
                    SwitchListTile(
                      title: const Text("Register as Admin"),
                      value: isAdmin,
                      onChanged: (val) => setState(() => isAdmin = val),
                    ),
                    const SizedBox(height: 24),
                    ElevatedButton(
                      onPressed: signup,
                      child: const Text("Sign Up"),
                    ),
                  ],
                ),
              ),
            ),
    );
  }
}
