import 'package:flutter/material.dart';
import '../../utils/constants.dart'; // Assuming you have a colors/constants file
import '../../routes.dart'; // For navigation

class ThumbScanScreen extends StatelessWidget {
  const ThumbScanScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.bgColor,
      body: Center(
        child: Padding(
          padding: const EdgeInsets.all(24.0),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              // Replace this with your thumb scan animation or image
              Image.asset('assets/thumb_scan.gif', height: 200),

              const SizedBox(height: 40),
              Text(
                "Welcome to Secure",
                style: Theme.of(context).textTheme.headlineMedium?.copyWith(fontWeight: FontWeight.bold),
              ),
              const SizedBox(height: 12),
              Text(
                "Tap below to scan and begin",
                style: Theme.of(context).textTheme.bodyLarge,
              ),
              const SizedBox(height: 40),
              ElevatedButton(
                onPressed: () {
                  Navigator.pushReplacementNamed(context, AppRoutes.signup);
                },
                style: ElevatedButton.styleFrom(
                  padding: const EdgeInsets.symmetric(horizontal: 40, vertical: 16),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                ),
                child: const Text("Scan to Enter"),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
