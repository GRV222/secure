// lib/screens/auth/login_screen.dart
import 'package:flutter/material.dart';
import '../../services/auth_service.dart';

class LoginScreen extends StatelessWidget {
  final AuthService _authService = AuthService();

  LoginScreen({super.key});

  void _authenticate(BuildContext context) async {
    final success = await _authService.authenticateWithBiometrics();
    if (success) {
      Navigator.pushReplacementNamed(context, '/userInfo'); // or home/admin
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("Authentication failed")),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: ElevatedButton.icon(
          icon: const Icon(Icons.fingerprint),
          label: const Text("Login with Thumb"),
          onPressed: () => _authenticate(context),
        ),
      ),
    );
  }
}
