import 'package:cloud_firestore/cloud_firestore.dart';

class PollOption {
  final String option;
  final int votes;
  PollOption({required this.option, required this.votes});

  factory PollOption.fromMap(Map<String, dynamic> map) {
    return PollOption(
      option: map['option'],
      votes: map['votes'] as int,
    );
  }

  Map<String, dynamic> toMap() => {
        'option': option,
        'votes': votes,
      };
}

class PollModel {
  final String id;
  final String question;
  final List<PollOption> options;
  final DateTime createdAt;

  PollModel({
    required this.id,
    required this.question,
    required this.options,
    required this.createdAt,
  });

  factory PollModel.fromMap(String id, Map<String, dynamic> map) {
    return PollModel(
      id: id,
      question: map['question'],
      options: (map['options'] as List<dynamic>)
          .map((o) => PollOption.fromMap(o as Map<String, dynamic>))
          .toList(),
      createdAt: (map['createdAt'] as Timestamp).toDate(),
    );
  }

  Map<String, dynamic> toMap() => {
        'question': question,
        'options': options.map((o) => o.toMap()).toList(),
        'createdAt': createdAt,
      };
}
