import 'package:cloud_firestore/cloud_firestore.dart';

class CompetitionModel {
  final String id;
  final String name;
  final String category;
  final DateTime startDate;
  final DateTime endDate;
  final bool isFree;
  final double entryFee;

  CompetitionModel({
    required this.id,
    required this.name,
    required this.category,
    required this.startDate,
    required this.endDate,
    required this.isFree,
    required this.entryFee,
  });

  factory CompetitionModel.fromMap(String id, Map<String, dynamic> map) {
    return CompetitionModel(
      id: id,
      name: map['name'],
      category: map['category'],
      startDate: (map['startDate'] as Timestamp).toDate(),
      endDate: (map['endDate'] as Timestamp).toDate(),
      isFree: map['isFree'],
      entryFee: (map['entryFee'] as num).toDouble(),
    );
  }

  Map<String, dynamic> toMap() => {
        'name': name,
        'category': category,
        'startDate': startDate,
        'endDate': endDate,
        'isFree': isFree,
        'entryFee': entryFee,
      };
}
