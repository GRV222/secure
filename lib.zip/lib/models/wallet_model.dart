class WalletModel {
  final String userId;
  final double shrBalance;
  final double daBalance;
  final bool isLocked;

  WalletModel({
    required this.userId,
    required this.shrBalance,
    required this.daBalance,
    required this.isLocked,
  });

  factory WalletModel.fromMap(Map<String, dynamic> map) {
    return WalletModel(
      userId: map['userId'],
      shrBalance: (map['shrBalance'] as num).toDouble(),
      daBalance: (map['daBalance'] as num).toDouble(),
      isLocked: map['isLocked'],
    );
  }

  Map<String, dynamic> toMap() => {
        'userId': userId,
        'shrBalance': shrBalance,
        'daBalance': daBalance,
        'isLocked': isLocked,
      };
}
