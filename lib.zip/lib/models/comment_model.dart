// models/comment_model.dart
class CommentModel {
  final String id;
  final String userId;
  final String postId;
  final String text;
  final DateTime createdAt;

  CommentModel({
    required this.id,
    required this.userId,
    required this.postId,
    required this.text,
    required this.createdAt,
  });

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'userId': userId,
      'postId': postId,
      'text': text,
      'createdAt': createdAt.toIso8601String(),
    };
  }

  factory CommentModel.fromMap(Map<String, dynamic> map) {
    return CommentModel(
      id: map['id'],
      userId: map['userId'],
      postId: map['postId'],
      text: map['text'],
      createdAt: DateTime.parse(map['createdAt']),
    );
  }
}
