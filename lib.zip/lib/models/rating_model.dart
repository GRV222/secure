import 'package:cloud_firestore/cloud_firestore.dart';

class RatingModel {
  final String id;
  final String postId;
  final String userId;
  final double score;
  final DateTime createdAt;

  RatingModel({
    required this.id,
    required this.postId,
    required this.userId,
    required this.score,
    required this.createdAt,
  });

  factory RatingModel.fromMap(String id, Map<String, dynamic> map) {
    return RatingModel(
      id: id,
      postId: map['postId'],
      userId: map['userId'],
      score: (map['score'] as num).toDouble(),
      createdAt: (map['createdAt'] as Timestamp).toDate(),
    );
  }

  Map<String, dynamic> toMap() => {
        'postId': postId,
        'userId': userId,
        'score': score,
        'createdAt': createdAt,
      };
}
