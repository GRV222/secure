import 'package:cloud_firestore/cloud_firestore.dart';
import 'media_model.dart';

/// Defines whether this is a user “dare” or an org “task”
enum DareTaskType { dare, task }

class DareTaskModel {
  final String id;
  final DareTaskType type;
  final String authorId; // UID of user or org that created it
  final String title; // Short title or name of dare/task
  final String description; // Full description or instructions
  final List<MediaModel> media; // Up to 4 media attachments
  final List<String>?
      taggedUserIds; // Optional list of user IDs if specific users were tagged
  final DateTime createdAt;
  final DateTime? deadline; // For tasks, optional deadline
  final bool
      isOpen; // If true, anyone can participate; if false, only tagged users

  DareTaskModel({
    required this.id,
    required this.type,
    required this.authorId,
    required this.title,
    required this.description,
    required this.media,
    this.taggedUserIds,
    required this.createdAt,
    this.deadline,
    this.isOpen = true,
  });

  factory DareTaskModel.fromMap(String id, Map<String, dynamic> map) {
    return DareTaskModel(
      id: id,
      type: DareTaskType.values.firstWhere(
        (e) => e.toString().split('.').last == map['type'],
      ),
      authorId: map['authorId'],
      title: map['title'],
      description: map['description'],
      media: (map['media'] as List<dynamic>?)
              ?.map((m) => MediaModel.fromMap(m as Map<String, dynamic>))
              .toList() ??
          [],
      taggedUserIds: (map['taggedUserIds'] as List<dynamic>?)
          ?.map((u) => u as String)
          .toList(),
      createdAt: (map['createdAt'] as Timestamp).toDate(),
      deadline: map['deadline'] != null
          ? (map['deadline'] as Timestamp).toDate()
          : null,
      isOpen: map['isOpen'] ?? true,
    );
  }

  Map<String, dynamic> toMap() => {
        'type': type.toString().split('.').last,
        'authorId': authorId,
        'title': title,
        'description': description,
        'media': media.map((m) => m.toMap()).toList(),
        'taggedUserIds': taggedUserIds,
        'createdAt': createdAt,
        'deadline': deadline,
        'isOpen': isOpen,
      };
}
