// lib/models/post_model.dart
enum PostType {
  competition,
  dare,
  task,
  idea,
  poll,
}

class PostModel {
  final String postId;
  final String authorId;
  final PostType type;
  final String caption;
  final List<String> hashtags;
  final List<String> mediaUrls;
  final DateTime createdAt;
  final bool isPublic;
  final double? rating; // Avg rating if applicable
  final Map<String, dynamic>?
      extraData; // for poll options, idea metadata, etc.

  PostModel({
    required this.postId,
    required this.authorId,
    required this.type,
    required this.caption,
    required this.hashtags,
    required this.mediaUrls,
    required this.createdAt,
    required this.isPublic,
    this.rating,
    this.extraData,
  });

  factory PostModel.fromMap(Map<String, dynamic> map, String id) {
    return PostModel(
      postId: id,
      authorId: map['authorId'],
      type: PostType.values.firstWhere((e) => e.name == map['type']),
      caption: map['caption'],
      hashtags: List<String>.from(map['hashtags']),
      mediaUrls: List<String>.from(map['mediaUrls']),
      createdAt: DateTime.parse(map['createdAt']),
      isPublic: map['isPublic'],
      rating: map['rating']?.toDouble(),
      extraData: map['extraData'],
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'authorId': authorId,
      'type': type.name,
      'caption': caption,
      'hashtags': hashtags,
      'mediaUrls': mediaUrls,
      'createdAt': createdAt.toIso8601String(),
      'isPublic': isPublic,
      'rating': rating,
      'extraData': extraData,
    };
  }
}
