// lib/models/user_model.dart
class UserModel {
  final String uid;
  final String name;
  final String phone;
  final int age;
  final String profession;
  final String? gender;
  final String? profileImageUrl;
  final bool isAdmin;

  UserModel({
    required this.uid,
    required this.name,
    required this.phone,
    required this.age,
    required this.profession,
    this.gender,
    this.profileImageUrl,
    this.isAdmin = false,
  });

  factory UserModel.fromMap(Map<String, dynamic> map, String uid) {
    return UserModel(
      uid: uid,
      name: map['name'],
      phone: map['phone'],
      age: map['age'],
      profession: map['profession'],
      gender: map['gender'],
      profileImageUrl: map['profileImageUrl'],
      isAdmin: map['isAdmin'] ?? false,
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'name': name,
      'phone': phone,
      'age': age,
      'profession': profession,
      'gender': gender,
      'profileImageUrl': profileImageUrl,
      'isAdmin': isAdmin,
    };
  }
}
