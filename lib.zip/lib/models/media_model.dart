enum MediaType { image, video, audio, document }

class MediaModel {
  final String url;
  final MediaType type;

  MediaModel({required this.url, required this.type});

  factory MediaModel.fromMap(Map<String, dynamic> map) {
    return MediaModel(
      url: map['url'],
      type: MediaType.values.firstWhere(
        (e) => e.toString().split('.').last == map['type'],
      ),
    );
  }

  Map<String, dynamic> toMap() => {
        'url': url,
        'type': type.toString().split('.').last,
      };
}
