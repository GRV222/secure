import 'package:cloud_firestore/cloud_firestore.dart';

class PostService {
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  Future<void> createPost({
    required String uid,
    required String username,
    required String content,
    required String mediaUrl,
    required List<String> hashtags,
  }) async {
    try {
      await _firestore.collection('posts').add({
        'uid': uid,
        'username': username,
        'content': content,
        'mediaUrl': mediaUrl,
        'hashtags': hashtags,
        'rating': 0.0,
        'timestamp': FieldValue.serverTimestamp(),
      });
    } catch (e) {
      rethrow;
    }
  }

  Stream<QuerySnapshot> getAllPosts() {
    return _firestore
        .collection('posts')
        .orderBy('timestamp', descending: true)
        .snapshots();
  }
}
