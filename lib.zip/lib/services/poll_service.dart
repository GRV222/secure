import 'package:cloud_firestore/cloud_firestore.dart';
import '../models/poll_model.dart';

class PollService {
  final _polls = FirebaseFirestore.instance.collection('polls');

  Future<List<PollModel>> fetchAllPolls() async {
    final snap = await _polls.orderBy('createdAt', descending: true).get();
    return snap.docs.map((d) => PollModel.fromMap(d.id, d.data())).toList();
  }

  Future<void> createPoll(PollModel poll) async {
    await _polls.doc(poll.id).set(poll.toMap());
  }

  Future<void> vote(String pollId, String option) async {
    final doc = _polls.doc(pollId);
    final data = (await doc.get()).data()!;
    List options = data['options'];
    options = options.map((o) {
      if (o['option'] == option) o['votes'] = (o['votes'] as int) + 1;
      return o;
    }).toList();
    await doc.update({'options': options});
  }
}
