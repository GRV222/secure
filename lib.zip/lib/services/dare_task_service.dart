import 'dart:io';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_storage/firebase_storage.dart';
import '../models/dare_task_model.dart';

class DareTaskService {
  final _col = FirebaseFirestore.instance.collection('dare_tasks');
  final _storage = FirebaseStorage.instance;

  Future<List<DareTaskModel>> fetchAll() async {
    final snap = await _col.orderBy('createdAt', descending: true).get();
    return snap.docs.map((d) => DareTaskModel.fromMap(d.id, d.data())).toList();
  }

  Future<void> create(DareTaskModel model, List<File>? mediaFiles) async {
    final id = _col.doc().id;
    List<Map<String, dynamic>> mediaData = [];

    if (mediaFiles != null) {
      for (var file in mediaFiles) {
        final ref = _storage
            .ref('dare_tasks/$id/${DateTime.now().millisecondsSinceEpoch}');
        await ref.putFile(file);
        mediaData.add({
          'url': await ref.getDownloadURL(),
          'type': _detectMediaType(file)
        });
      }
    }

    await _col.doc(id).set({
      ...model.toMap(),
      'media': mediaData,
      'createdAt': FieldValue.serverTimestamp(),
    });
  }

  String _detectMediaType(File file) {
    final ext = file.path.split('.').last.toLowerCase();
    if (['jpg', 'png'].contains(ext)) return 'image';
    if (['mp4', 'mov'].contains(ext)) return 'video';
    if (['mp3', 'wav'].contains(ext)) return 'audio';
    return 'document';
  }
}
