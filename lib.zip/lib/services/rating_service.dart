import 'package:cloud_firestore/cloud_firestore.dart';
import '../models/rating_model.dart';

class RatingService {
  final _col = FirebaseFirestore.instance.collection('ratings');

  Future<List<RatingModel>> fetchRatings(String postId) async {
    final snap = await _col.where('postId', isEqualTo: postId).get();
    return snap.docs.map((d) => RatingModel.fromMap(d.id, d.data())).toList();
  }

  Future<void> submitRating(String postId, double score) async {
    final id = _col.doc().id;
    await _col.doc(id).set({
      'postId': postId,
      'userId': FirebaseFirestore.instance.app.options.appId, // adjust
      'score': score,
      'createdAt': FieldValue.serverTimestamp(),
    });
  }
}
