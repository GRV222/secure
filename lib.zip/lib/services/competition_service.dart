import 'package:cloud_firestore/cloud_firestore.dart';
import '../models/competition_model.dart';

class CompetitionService {
  final _col = FirebaseFirestore.instance.collection('competitions');

  Future<List<CompetitionModel>> fetchAll() async {
    final snap = await _col.orderBy('startDate', descending: true).get();
    return snap.docs
        .map((d) => CompetitionModel.fromMap(d.id, d.data()))
        .toList();
  }

  Future<void> create(CompetitionModel model) async {
    await _col.doc(model.id).set(model.toMap());
  }
}
