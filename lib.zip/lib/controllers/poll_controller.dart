import 'package:get/get.dart';
import '../models/poll_model.dart';
import '../services/poll_service.dart';

class PollController extends GetxController {
  static PollController instance = Get.find();

  final polls = <PollModel>[].obs;
  final PollService _service = PollService();

  @override
  void onInit() {
    super.onInit();
    fetchPolls();
  }

  Future<void> fetchPolls() async {
    try {
      final data = await _service.fetchAllPolls();
      polls.assignAll(data);
    } catch (e) {
      Get.snackbar('Error', 'Failed to load polls');
    }
  }

  Future<void> createPoll(PollModel poll) async {
    await _service.createPoll(poll);
    await fetchPolls();
  }

  Future<void> vote(String pollId, String option) async {
    await _service.vote(pollId, option);
    await fetchPolls();
  }
}
