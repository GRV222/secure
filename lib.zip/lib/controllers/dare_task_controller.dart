import 'dart:io';
import 'package:get/get.dart';
import '../models/dare_task_model.dart';
import '../services/dare_task_service.dart';

class DareTaskController extends GetxController {
  static DareTaskController instance = Get.find();

  final dareTasks = <DareTaskModel>[].obs;
  final DareTaskService _service = DareTaskService();

  @override
  void onInit() {
    super.onInit();
    fetchAll();
  }

  Future<void> fetchAll() async {
    try {
      final data = await _service.fetchAll();
      dareTasks.assignAll(data);
    } catch (e) {
      Get.snackbar('Error', 'Failed to load dares/tasks');
    }
  }

  Future<void> create(DareTaskModel model, List<File>? mediaFiles) async {
    await _service.create(model, mediaFiles);
    await fetchAll();
  }
}
