import 'package:get/get.dart';
import '../models/competition_model.dart';
import '../services/competition_service.dart';

class CompetitionController extends GetxController {
  static CompetitionController instance = Get.find();

  final competitions = <CompetitionModel>[].obs;
  final CompetitionService _service = CompetitionService();

  @override
  void onInit() {
    super.onInit();
    fetchCompetitions();
  }

  Future<void> fetchCompetitions() async {
    try {
      final data = await _service.fetchAll();
      competitions.assignAll(data);
    } catch (e) {
      Get.snackbar('Error', 'Failed to load competitions');
    }
  }

  Future<void> createCompetition(CompetitionModel model) async {
    await _service.create(model);
    await fetchCompetitions();
  }
}
