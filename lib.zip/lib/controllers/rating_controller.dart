import 'package:get/get.dart';
import '../models/rating_model.dart';
import '../services/rating_service.dart';

class RatingController extends GetxController {
  static RatingController instance = Get.find();

  final ratings = <RatingModel>[].obs;
  final RatingService _service = RatingService();

  Future<void> fetchRatingsForPost(String postId) async {
    try {
      final data = await _service.fetchRatings(postId);
      ratings.assignAll(data);
    } catch (e) {
      Get.snackbar('Error', 'Failed to load ratings');
    }
  }

  Future<void> ratePost(String postId, double score) async {
    await _service.submitRating(postId, score);
    await fetchRatingsForPost(postId);
  }
}
