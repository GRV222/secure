import 'package:flutter/material.dart';

// Auth
import 'screens/auth/signup_screen.dart';

// Admin
import 'screens/admin/admin_dashboard_screen.dart';

// General
import 'screens/general/home_screen.dart';
import 'screens/general/splash_screen.dart';

// Post Related
import 'screens/post/create_post_screen.dart';
import 'screens/post/comment_screen.dart';

// Optional: Future routes
// import 'screens/other/competition_screen.dart';
// import 'screens/other/poll_screen.dart';

class AppRoutes {
  static const String splash = '/';
  static const String signup = '/signup';
  static const String home = '/home';
  static const String adminDashboard = '/admin_dashboard';
  static const String createPost = '/create_post';
  static const String comments = '/comments';

  static Route<dynamic> generateRoute(RouteSettings settings) {
    switch (settings.name) {
      case splash:
        return MaterialPageRoute(builder: (_) => const SplashScreen());
      case signup:
        return MaterialPageRoute(builder: (_) => const SignupScreen());
      case home:
        return MaterialPageRoute(builder: (_) => const HomeScreen());
      case adminDashboard:
        return MaterialPageRoute(builder: (_) => const AdminDashboardScreen());
      case createPost:
        return MaterialPageRoute(builder: (_) => const CreatePostScreen());
      case comments:
        return MaterialPageRoute(builder: (_) => const CommentScreen());
      default:
        return MaterialPageRoute(
          builder: (_) =>
              const Scaffold(body: Center(child: Text('Route not found'))),
        );
    }
  }
}
