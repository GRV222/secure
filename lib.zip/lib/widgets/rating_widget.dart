import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:percent_indicator/circular_percent_indicator.dart';

class RatingWidget extends StatefulWidget {
  final String postId;
  final String userId;

  const RatingWidget({super.key, required this.postId, required this.userId});

  @override
  State<RatingWidget> createState() => _RatingWidgetState();
}

class _RatingWidgetState extends State<RatingWidget> {
  int? userRating;
  double avgRating = 0;
  int totalRatings = 0;
  final firestore = FirebaseFirestore.instance;

  @override
  void initState() {
    super.initState();
    fetchUserRating();
    fetchAvgRating();
  }

  void fetchUserRating() async {
    final doc = await firestore
        .collection('posts')
        .doc(widget.postId)
        .collection('ratings')
        .doc(widget.userId)
        .get();

    if (doc.exists) {
      setState(() {
        userRating = doc['rating'];
      });
    }
  }

  void fetchAvgRating() async {
    final doc = await firestore.collection('posts').doc(widget.postId).get();
    if (doc.exists) {
      setState(() {
        avgRating = doc.data()?['avgRating']?.toDouble() ?? 0;
        totalRatings = doc.data()?['totalRatings']?.toInt() ?? 0;
      });
    }
  }

  void submitRating(int rating) async {
    if (userRating != null) return; // already rated

    final ratingRef = firestore
        .collection('posts')
        .doc(widget.postId)
        .collection('ratings')
        .doc(widget.userId);

    await ratingRef.set({
      'rating': rating,
      'createdAt': DateTime.now().toIso8601String(),
    });

    // Recalculate average
    final allRatings = await firestore
        .collection('posts')
        .doc(widget.postId)
        .collection('ratings')
        .get();

    final ratings = allRatings.docs.map((doc) => doc['rating'] as int).toList();
    final newAvg = ratings.reduce((a, b) => a + b) / ratings.length;

    await firestore.collection('posts').doc(widget.postId).update({
      'avgRating': double.parse(newAvg.toStringAsFixed(1)),
      'totalRatings': ratings.length,
    });

    setState(() {
      userRating = rating;
      avgRating = newAvg;
      totalRatings = ratings.length;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        CircularPercentIndicator(
          radius: 50.0,
          lineWidth: 8.0,
          percent: (avgRating / 10).clamp(0.0, 1.0),
          center: Text(
            "${avgRating.toStringAsFixed(1)} / 10",
            style: const TextStyle(fontSize: 16),
          ),
          progressColor: Colors.blue,
        ),
        const SizedBox(height: 8),
        userRating == null
            ? Wrap(
                spacing: 6,
                children: List.generate(10, (i) {
                  return ElevatedButton(
                    onPressed: () => submitRating(i + 1),
                    child: Text("${i + 1}"),
                  );
                }),
              )
            : Text("You rated: $userRating",
                style: const TextStyle(fontSize: 16)),
        Text("Total Ratings: $totalRatings",
            style: const TextStyle(fontSize: 12)),
      ],
    );
  }
}
