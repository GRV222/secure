import 'package:flutter/material.dart';
import '../../routes.dart';

class FloatingPostButton extends StatelessWidget {
  const FloatingPostButton({super.key});

  @override
  Widget build(BuildContext context) {
    return FloatingActionButton(
      onPressed: () => Navigator.pushNamed(context, '/create_post'),
      child: const Icon(Icons.add),
    );
  }
}
