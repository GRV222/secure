import 'dart:io';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:file_picker/file_picker.dart';

class MediaUploader extends StatefulWidget {
  final Function(List<File>) onFilesSelected;
  const MediaUploader({super.key, required this.onFilesSelected});

  @override
  State<MediaUploader> createState() => _MediaUploaderState();
}

class _MediaUploaderState extends State<MediaUploader> {
  final List<File> _files = [];

  Future<void> _pickMedia() async {
    if (_files.length >= 4) return;
    // Let user pick type
    final type = await showModalBottomSheet<String>(
      context: context,
      builder: (_) => ListView(
        shrinkWrap: true,
        children: ['Image', 'Video', 'Audio', 'Document']
            .map((e) => ListTile(
                title: Text(e), onTap: () => Navigator.pop(context, e)))
            .toList(),
      ),
    );
    if (type == null) return;

    File? file;
    if (type == 'Image') {
      final picked = await ImagePicker().pickImage(source: ImageSource.gallery);
      if (picked != null) file = File(picked.path);
    } else if (type == 'Video') {
      final picked = await ImagePicker().pickVideo(source: ImageSource.gallery);
      if (picked != null) file = File(picked.path);
    } else {
      final result = await FilePicker.platform.pickFiles(allowMultiple: false);
      if (result != null && result.files.single.path != null) {
        file = File(result.files.single.path!);
      }
    }
    if (file != null) {
      setState(() => _files.add(file!));
      widget.onFilesSelected(_files);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Wrap(
          spacing: 8,
          runSpacing: 8,
          children: _files
              .map((f) => Stack(
                    children: [
                      Image.file(f, width: 80, height: 80, fit: BoxFit.cover),
                      Positioned(
                        right: 0,
                        top: 0,
                        child: GestureDetector(
                          onTap: () => setState(() {
                            _files.remove(f);
                            widget.onFilesSelected(_files);
                          }),
                          child: const Icon(Icons.close,
                              size: 18, color: Colors.red),
                        ),
                      )
                    ],
                  ))
              .toList(),
        ),
        const SizedBox(height: 8),
        ElevatedButton.icon(
          onPressed: _pickMedia,
          icon: const Icon(Icons.attach_file),
          label: Text('Attach (${_files.length}/4)'),
        )
      ],
    );
  }
}
