import 'package:flutter/material.dart';

class PostCard extends StatelessWidget {
  final String content;
  final String? mediaUrl;
  final List<String> hashtags;
  final String username; // In future, replace with User model

  const PostCard({
    super.key,
    required this.content,
    required this.mediaUrl,
    required this.hashtags,
    required this.username,
  });

  @override
  Widget build(BuildContext context) {
    return Card(
      margin: const EdgeInsets.symmetric(vertical: 8, horizontal: 16),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      elevation: 4,
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(username, style: const TextStyle(fontWeight: FontWeight.bold)),
            const SizedBox(height: 8),
            Text(content),
            if (mediaUrl != null && mediaUrl!.isNotEmpty) ...[
              const SizedBox(height: 12),
              ClipRRect(
                borderRadius: BorderRadius.circular(10),
                child: Image.network(mediaUrl!, height: 200, fit: BoxFit.cover),
              ),
            ],
            const SizedBox(height: 12),
            Wrap(
              spacing: 6,
              children:
                  hashtags.map((tag) => Chip(label: Text('#$tag'))).toList(),
            ),
            const Divider(height: 20),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                IconButton(onPressed: () {}, icon: const Icon(Icons.comment)),
                IconButton(
                    onPressed: () {}, icon: const Icon(Icons.star_border)),
              ],
            )
          ],
        ),
      ),
    );
  }
}
