import 'package:flutter/material.dart';
import '../models/poll_model.dart';
import '../services/poll_service.dart';

class PollProvider with ChangeNotifier {
  final PollService _service = PollService();
  List<PollModel> _polls = [];
  bool _isLoading = false;

  List<PollModel> get polls => _polls;
  bool get isLoading => _isLoading;

  Future<void> loadPolls() async {
    _isLoading = true;
    notifyListeners();
    _polls = await _service.fetchAllPolls();
    _isLoading = false;
    notifyListeners();
  }

  Future<void> createPoll(PollModel model) async {
    await _service.createPoll(model);
    await loadPolls();
  }

  Future<void> vote(String pollId, String option) async {
    await _service.vote(pollId, option);
    await loadPolls();
  }
}
