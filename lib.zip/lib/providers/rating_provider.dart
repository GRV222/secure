import 'package:flutter/material.dart';
import '../models/rating_model.dart';
import '../services/rating_service.dart';

class RatingProvider with ChangeNotifier {
  final RatingService _service = RatingService();
  List<RatingModel> _ratings = [];
  bool _isLoading = false;

  List<RatingModel> get ratings => _ratings;
  bool get isLoading => _isLoading;

  Future<void> loadRatings(String postId) async {
    _isLoading = true;
    notifyListeners();
    _ratings = await _service.fetchRatings(postId);
    _isLoading = false;
    notifyListeners();
  }

  Future<void> submitRating(String postId, double score) async {
    await _service.submitRating(postId, score);
    await loadRatings(postId);
  }
}
