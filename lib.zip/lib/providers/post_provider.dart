import 'dart:io';
import 'package:flutter/material.dart';
import '../models/post_model.dart';
import '../services/post_service.dart';

class PostProvider with ChangeNotifier {
  final PostService _service = PostService();
  List<PostModel> _posts = [];
  bool _isLoading = false;

  List<PostModel> get posts => _posts;
  bool get isLoading => _isLoading;

  Future<void> loadPosts() async {
    _isLoading = true;
    notifyListeners();
    _posts = await _service.fetchAllPosts();
    _isLoading = false;
    notifyListeners();
  }

  Future<void> createPost({
    required String content,
    required String hashtag,
    required PostType type,
    List<File>? mediaFiles,
    required bool allowComments,
  }) async {
    await _service.createPost(
      content: content,
      hashtag: hashtag,
      type: type,
      mediaFiles: mediaFiles,
      allowComments: allowComments,
    );
    await loadPosts();
  }
}
