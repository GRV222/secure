import 'dart:io';
import 'package:flutter/material.dart';
import '../models/dare_task_model.dart';
import '../services/dare_task_service.dart';

class DareTaskProvider with ChangeNotifier {
  final DareTaskService _service = DareTaskService();
  List<DareTaskModel> _items = [];
  bool _isLoading = false;

  List<DareTaskModel> get items => _items;
  bool get isLoading => _isLoading;

  Future<void> loadAll() async {
    _isLoading = true;
    notifyListeners();
    _items = await _service.fetchAll();
    _isLoading = false;
    notifyListeners();
  }

  Future<void> create(
    DareTaskModel model,
    List<File>? mediaFiles,
  ) async {
    await _service.create(model, mediaFiles);
    await loadAll();
  }
}
