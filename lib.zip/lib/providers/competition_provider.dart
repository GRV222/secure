import 'package:flutter/material.dart';
import '../models/competition_model.dart';
import '../services/competition_service.dart';

class CompetitionProvider with ChangeNotifier {
  final CompetitionService _service = CompetitionService();
  List<CompetitionModel> _competitions = [];
  bool _isLoading = false;

  List<CompetitionModel> get competitions => _competitions;
  bool get isLoading => _isLoading;

  Future<void> loadAll() async {
    _isLoading = true;
    notifyListeners();
    _competitions = await _service.fetchAll();
    _isLoading = false;
    notifyListeners();
  }

  Future<void> create(CompetitionModel model) async {
    await _service.create(model);
    await loadAll();
  }
}
