import 'package:flutter/material.dart';

class CreatePollScreen extends StatelessWidget {
  const CreatePollScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Create Poll')),
      body: const Center(child: Text('Poll Creation UI goes here')),
    );
  }
}

class CreateComparisonScreen extends StatelessWidget {
  const CreateComparisonScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Create Comparison')),
      body: const Center(child: Text('Comparison Creation UI goes here')),
    );
  }
}

class CreateDareTaskScreen extends StatelessWidget {
  const CreateDareTaskScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Create Dare & Task')),
      body: const Center(child: Text('Dare & Task Creation UI goes here')),
    );
  }
}

class UploadMediaScreen extends StatelessWidget {
  const UploadMediaScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Upload Media')),
      body: const Center(child: Text('Media Upload UI goes here')),
    );
  }
}
