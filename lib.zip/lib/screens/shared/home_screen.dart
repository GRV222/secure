import 'package:flutter/material.dart';
import 'package:secure/screens/poll/poll_screen.dart';
import 'package:secure/screens/';
import 'package:secure/screens/dare_task/dare_task_screen.dart';
import '/upload_media_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  int _currentIndex = 0;

  final List<Widget> _tabs = [
    const Center(child: Text('Home Content')),
    const Center(child: Text('Polls')),
    const Center(child: Text('Comparison')),
    const Center(child: Text('Dare & Task')),
    const Center(child: Text('Profile')),
  ];

  void _showPostOptions(BuildContext context) {
    showModalBottomSheet(
      context: context,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (_) => Padding(
        padding: const EdgeInsets.all(20.0),
        child: Wrap(
          children: [
            ListTile(
              leading: const Icon(Icons.poll),
              title: const Text('Create Poll'),
              onTap: () {
                Navigator.pop(context);
                Navigator.push(
                    context,
                    MaterialPageRoute(
                        builder: (_) => const CreatePollScreen()));
              },
            ),
            ListTile(
              leading: const Icon(Icons.compare_arrows),
              title: const Text('Create Comparison'),
              onTap: () {
                Navigator.pop(context);
                Navigator.push(
                    context,
                    MaterialPageRoute(
                        builder: (_) => const CreateComparisonScreen()));
              },
            ),
            ListTile(
              leading: const Icon(Icons.flag),
              title: const Text('Create Dare & Task'),
              onTap: () {
                Navigator.pop(context);
                Navigator.push(
                    context,
                    MaterialPageRoute(
                        builder: (_) => const CreateDareTaskScreen()));
              },
            ),
            ListTile(
              leading: const Icon(Icons.image),
              title: const Text('Upload Media'),
              onTap: () {
                Navigator.pop(context);
                Navigator.push(
                    context,
                    MaterialPageRoute(
                        builder: (_) => const UploadMediaScreen()));
              },
            ),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Secure App')),
      body: _tabs[_currentIndex],
      floatingActionButton: FloatingActionButton(
        onPressed: () => _showPostOptions(context),
        child: const Icon(Icons.add),
      ),
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: _currentIndex,
        onTap: (index) => setState(() => _currentIndex = index),
        selectedItemColor: Colors.purple,
        items: const [
          BottomNavigationBarItem(icon: Icon(Icons.home), label: 'Home'),
          BottomNavigationBarItem(icon: Icon(Icons.poll), label: 'Polls'),
          BottomNavigationBarItem(
              icon: Icon(Icons.compare_arrows), label: 'Comparison'),
          BottomNavigationBarItem(icon: Icon(Icons.flag), label: 'Dare'),
          BottomNavigationBarItem(icon: Icon(Icons.person), label: 'Profile'),
        ],
      ),
    );
  }
}
