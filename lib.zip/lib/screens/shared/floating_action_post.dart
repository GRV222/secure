import 'package:flutter/material.dart';

class FloatingActionPost extends StatelessWidget {
  final VoidCallback onPressed;
  final IconData icon;

  const FloatingActionPost({
    super.key,
    required this.onPressed,
    this.icon = Icons.add,
  });

  @override
  Widget build(BuildContext context) {
    return FloatingActionButton(
      onPressed: onPressed,
      child: Icon(icon),
    );
  }
}
