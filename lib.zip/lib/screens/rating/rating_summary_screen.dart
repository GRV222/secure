import 'package:flutter/material.dart';

class RatingSummaryScreen extends StatelessWidget {
  const RatingSummaryScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Rating Summary')),
      body: const Center(child: Text('Display summary of ratings here')),
    );
  }
}
