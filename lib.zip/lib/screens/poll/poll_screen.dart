import 'package:flutter/material.dart';

class PollScreen extends StatelessWidget {
  const PollScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Polls')),
      body: const Center(child: Text('List of polls')),
    );
  }
}
