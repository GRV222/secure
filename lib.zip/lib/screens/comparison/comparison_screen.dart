import 'dart:math';
import 'package:flutter/material.dart';

class ComparisonCard {
  final String title;
  final String optionA;
  final String optionB;
  final String imageA;
  final String imageB;

  ComparisonCard({
    required this.title,
    required this.optionA,
    required this.optionB,
    required this.imageA,
    required this.imageB,
  });
}

class ComparisonSwipeScreen extends StatefulWidget {
  const ComparisonSwipeScreen({super.key});

  @override
  State<ComparisonSwipeScreen> createState() => _ComparisonSwipeScreenState();
}

class _ComparisonSwipeScreenState extends State<ComparisonSwipeScreen> {
  final List<ComparisonCard> _cards = [
    ComparisonCard(
      title: "Which snack is better?",
      optionA: "Samosa",
      optionB: "Burger",
      imageA: "https://via.placeholder.com/150x150.png?text=Samosa",
      imageB: "https://via.placeholder.com/150x150.png?text=Burger",
    ),
    ComparisonCard(
      title: "Choose your ride",
      optionA: "Bike",
      optionB: "Car",
      imageA: "https://via.placeholder.com/150x150.png?text=Bike",
      imageB: "https://via.placeholder.com/150x150.png?text=Car",
    ),
    ComparisonCard(
      title: "Preferred vacation?",
      optionA: "Beach",
      optionB: "Mountains",
      imageA: "https://via.placeholder.com/150x150.png?text=Beach",
      imageB: "https://via.placeholder.com/150x150.png?text=Mountains",
    ),
    ComparisonCard(
      title: "Which phone?",
      optionA: "iPhone",
      optionB: "Samsung",
      imageA: "https://via.placeholder.com/150x150.png?text=iPhone",
      imageB: "https://via.placeholder.com/150x150.png?text=Samsung",
    ),
    ComparisonCard(
      title: "Pick your pet",
      optionA: "Dog",
      optionB: "Cat",
      imageA: "https://via.placeholder.com/150x150.png?text=Dog",
      imageB: "https://via.placeholder.com/150x150.png?text=Cat",
    ),
  ];

  int _currentIndex = 0;

  void _onSwipe(String choice) {
    if (_currentIndex < _cards.length - 1) {
      setState(() {
        _currentIndex++;
      });
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("No more comparisons!")),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    final card = _cards[_currentIndex];

    return Scaffold(
      appBar: AppBar(title: const Text("Comparison (Swipe Style)")),
      body: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Text(card.title,
              style:
                  const TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
          const SizedBox(height: 20),
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              _buildOptionCard(card.optionA, card.imageA, () => _onSwipe('A')),
              const SizedBox(width: 20),
              _buildOptionCard(card.optionB, card.imageB, () => _onSwipe('B')),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildOptionCard(String label, String imageUrl, VoidCallback onTap) {
    return GestureDetector(
      onTap: onTap,
      child: Card(
        elevation: 6,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
        child: SizedBox(
          width: 150,
          height: 220,
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Image.network(imageUrl,
                  width: 120, height: 120, fit: BoxFit.cover),
              const SizedBox(height: 10),
              Text(label, style: const TextStyle(fontSize: 16)),
              const SizedBox(height: 10),
              const Icon(Icons.swipe, size: 24),
            ],
          ),
        ),
      ),
    );
  }
}
