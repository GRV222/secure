import 'package:flutter/material.dart';

class CreateDareScreen extends StatelessWidget {
  const CreateDareScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Create Dare')),
      body: const Center(child: Text('Form to create a dare')),
    );
  }
}
