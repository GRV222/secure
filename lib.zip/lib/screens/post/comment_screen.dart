import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:uuid/uuid.dart';

class CommentScreen extends StatefulWidget {
  final String postId;
  final String userId;

  const CommentScreen({
    super.key,
    required this.postId,
    required this.userId,
  });

  @override
  State<CommentScreen> createState() => _CommentScreenState();
}

class _CommentScreenState extends State<CommentScreen> {
  final TextEditingController commentController = TextEditingController();
  final FirebaseFirestore firestore = FirebaseFirestore.instance;
  final uuid = const Uuid();

  void addComment() async {
    final text = commentController.text.trim();
    if (text.isEmpty) return;

    final snapshot = await firestore
        .collection('comments')
        .where('postId', isEqualTo: widget.postId)
        .where('userId', isEqualTo: widget.userId)
        .get();

    if (snapshot.docs.length >= 2) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("You can only comment twice.")),
      );
      return;
    }

    final comment = {
      'id': uuid.v4(),
      'postId': widget.postId,
      'userId': widget.userId,
      'text': text,
      'createdAt': DateTime.now().toIso8601String(),
    };

    await firestore.collection('comments').doc(comment['id']).set(comment);

    commentController.clear();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Comments")),
      body: Column(
        children: [
          Expanded(
            child: StreamBuilder<QuerySnapshot>(
              stream: firestore
                  .collection('comments')
                  .where('postId', isEqualTo: widget.postId)
                  .orderBy('createdAt', descending: true)
                  .snapshots(),
              builder: (context, snapshot) {
                if (!snapshot.hasData)
                  return const Center(child: CircularProgressIndicator());

                final comments = snapshot.data!.docs;

                if (comments.isEmpty) {
                  return const Center(child: Text("No comments yet."));
                }

                return ListView.builder(
                  itemCount: comments.length,
                  itemBuilder: (_, index) {
                    final comment = comments[index];
                    return ListTile(
                      title: Text(comment['text']),
                      subtitle: Text("User: ${comment['userId']}"),
                      trailing: Text(
                        DateTime.parse(comment['createdAt'])
                            .toLocal()
                            .toString()
                            .substring(0, 16),
                        style: const TextStyle(fontSize: 10),
                      ),
                    );
                  },
                );
              },
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(12),
            child: Row(
              children: [
                Expanded(
                  child: TextField(
                    controller: commentController,
                    decoration: const InputDecoration(
                      hintText: "Add a comment...",
                      border: OutlineInputBorder(),
                    ),
                  ),
                ),
                const SizedBox(width: 8),
                ElevatedButton(
                  onPressed: addComment,
                  child: const Text("Send"),
                )
              ],
            ),
          ),
        ],
      ),
    );
  }
}
