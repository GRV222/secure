import 'package:flutter/material.dart';

class CreatePostScreen extends StatefulWidget {
  const CreatePostScreen({super.key});

  @override
  State<CreatePostScreen> createState() => _CreatePostScreenState();
}

class _CreatePostScreenState extends State<CreatePostScreen> {
  final TextEditingController contentController = TextEditingController();
  final TextEditingController hashtagController = TextEditingController();

  String? selectedMediaUrl; // Placeholder for uploaded media
  final List<String> hashtags = [];

  void addHashtag() {
    final tag = hashtagController.text.trim();
    if (tag.isNotEmpty && !hashtags.contains(tag)) {
      setState(() {
        hashtags.add(tag);
        hashtagController.clear();
      });
    }
  }

  void submitPost() {
    // TODO: Save to Firestore
    ScaffoldMessenger.of(context)
        .showSnackBar(const SnackBar(content: Text("Post created!")));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Create Post")),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: ListView(
          children: [
            TextField(
              controller: contentController,
              maxLines: 5,
              decoration: const InputDecoration(
                labelText: "What's on your mind?",
                border: OutlineInputBorder(),
              ),
            ),
            const SizedBox(height: 12),
            TextField(
              controller: hashtagController,
              decoration: InputDecoration(
                labelText: "Add Hashtag",
                suffixIcon: IconButton(
                  icon: const Icon(Icons.add),
                  onPressed: addHashtag,
                ),
              ),
            ),
            Wrap(
              spacing: 6,
              children:
                  hashtags.map((tag) => Chip(label: Text('#$tag'))).toList(),
            ),
            const SizedBox(height: 12),
            ElevatedButton.icon(
              icon: const Icon(Icons.upload),
              label: const Text("Upload Image/Video"),
              onPressed: () {
                // TODO: Media Picker
              },
            ),
            const SizedBox(height: 20),
            ElevatedButton(
              onPressed: submitPost,
              child: const Text("Post"),
            ),
          ],
        ),
      ),
    );
  }
}
