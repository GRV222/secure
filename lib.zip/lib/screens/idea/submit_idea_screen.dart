import 'package:flutter/material.dart';

class SubmitIdeaScreen extends StatelessWidget {
  const SubmitIdeaScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Submit Idea')),
      body: const Center(child: Text('Form to submit a new idea')),
    );
  }
}
