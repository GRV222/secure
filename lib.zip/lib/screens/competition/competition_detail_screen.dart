import 'package:flutter/material.dart';

class CompetitionDetailScreen extends StatelessWidget {
  const CompetitionDetailScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Competition Details')),
      body: const Center(child: Text('Details of the selected competition')),
    );
  }
}
